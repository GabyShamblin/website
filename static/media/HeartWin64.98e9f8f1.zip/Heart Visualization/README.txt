The camera can be moved using W, A, S, and D or holding down the left mouse button and moving the mouse.

The slider on the right-hand side zooms the camera in and out.

The play button in the top right corner starts/stops the heart pumping and blood movement animation.

Left click on the pop-ups to move through them and learn about the different parts of the human heart!
